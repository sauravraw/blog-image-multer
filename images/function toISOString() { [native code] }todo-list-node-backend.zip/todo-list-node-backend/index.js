// --  CRUD OPERATIONS
//  /tasklist/tasks/ --> GET (creating a new task)
//  /todolist/tasks/:taskid/ --> GET, PUT/PATCH, DELETE

// --  AUTHENTICATION
// /users/login
// /users/logout

const express = require("express");
const dotenv = require("dotenv");
const taskRoute = require("./routes/todoRoutes.js");

dotenv.config({
	path: "./config.env",
});

const app = express();
app.use(express.json());

app.use("/todoList", taskRoute);

app.listen(process.env.PORT, () => {
	console.log(`Server is listening on PORT : ${process.env.PORT}`);
});

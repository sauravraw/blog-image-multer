// all the endpoints for /todoList

const express = require("express");
const {
	getAllTasks,
	createTask,
	verifyPostRequest,
	getTaskById,
	updateTaskById,
	deleteTaskbyId,
} = require("../controllers/taskController.js");

const router = express.Router();

router.route("/tasks").get(getAllTasks).post(verifyPostRequest, createTask);

router
	.route("/tasks/:id")
	.get(getTaskById)
	.put(updateTaskById)
	.delete(deleteTaskbyId);

module.exports = router;

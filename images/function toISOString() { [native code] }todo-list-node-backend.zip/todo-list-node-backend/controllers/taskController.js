const fs = require("fs");
const path = require("path");

const Task = require("../models/Task.js");

const AppError = require("../helpers/appErrorClass.js");
const sendErrorMessage = require("../helpers/sendError.js");

const filePath = path.join(__dirname, "..", "data", "tasks.json");
const tasks = JSON.parse(fs.readFileSync(filePath, "utf-8"));

const verifyPostRequest = (req, res, next) => {
	const requiredProperties = ["taskName"];

	let result = requiredProperties.every((key) => {
		return req.body[key];
	});

	if (!result) {
		// res.status(400).json({
		// 	status: "unsuccessfull",
		// 	message: "requests body is not valid",
		// });
		sendErrorMessage(
			new AppError(400, "unsuccessful", "request body is not valid"),
			req,
			res
		);
	} else {
		next();
	}
};

const getAllTasks = (req, res, next) => {
	res.status(200).json({
		status: "successfull",
		data: tasks,
	});
};

const createTask = (req, res, next) => {
	console.log(req.body);

	let newTask = new Task(req.body.taskName);

	tasks.push(newTask);

	fs.writeFile(filePath, JSON.stringify(tasks, null, 2), (err) => {
		if (err) {
			res.status(500).json({
				status: "Internal error",
			});
			return err;
		}
		res.status(201).json({
			status: "Successful",
			data: [newTask],
		});
	});

	res.send("task created");
};

const getTaskById = (req, res, next) => {
	console.log("got task by id");
	res.send("task got");
};

const updateTaskById = (req, res, next) => {
	console.log("task updated by id");
	res.send("task updates");
};

const deleteTaskbyId = (req, res, next) => {
	console.log("task deleted by id");
	res.send("task deleted");
};

// export
module.exports.getAllTasks = getAllTasks;
module.exports.createTask = createTask;
module.exports.verifyPostRequest = verifyPostRequest;
module.exports.getTaskById = getTaskById;
module.exports.updateTaskById = updateTaskById;
module.exports.deleteTaskbyId = deleteTaskbyId;
